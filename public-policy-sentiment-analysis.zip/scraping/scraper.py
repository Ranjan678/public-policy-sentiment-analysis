# Web scraping logic
