# Text preprocessing logic
